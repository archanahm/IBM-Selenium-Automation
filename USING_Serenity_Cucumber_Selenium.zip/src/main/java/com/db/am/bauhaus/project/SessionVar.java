package com.db.am.bauhaus.project;

/**
 * Created by archanaHM on 15/10/2017.
 */
public enum SessionVar {
    SEARCH_TEXT;
}

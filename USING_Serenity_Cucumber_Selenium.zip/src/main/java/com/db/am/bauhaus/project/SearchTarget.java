package com.db.am.bauhaus.project;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SearchTarget {
    public final static Target INPUT_BOX = Target.the("the search input box").located(By.id("search_query_top"));
    public final static Target INPUT_BOX_BUTTON = Target.the("the search input button").located(By.cssSelector(".btn.btn-default.button-search"));
    public final static Target TOP_CATEGORIES_HEADER = Target.the("the top categories header").located(By.cssSelector("h1.page-heading"));
    public final static Target ALL_CATEGORIES_HEADER = Target.the("the all categories header").located(By.cssSelector("span.navigation_page"));
}

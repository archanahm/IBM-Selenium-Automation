package test.java;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.asserts.SoftAssert;

import utility.Constant;

public class BaseSpec {
	
	public SoftAssert s_assert = new SoftAssert();
	public WebDriver driver;
	private String BROWSER=System.getProperty("browser");
	private String driverPath=System.getProperty("user.dir")+"\\"+ "Driver";

	@BeforeSuite
	 
	  public void beforeMethod() throws Exception {

		if(BROWSER.equalsIgnoreCase("Firefox"))
					
	    {
		System.setProperty("webdriver.gecko.driver", driverPath+"\\geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		driver=new FirefoxDriver();
	    }
	    else if(BROWSER.equalsIgnoreCase("ie"))
	    {
	    	
	    	String service = driverPath+"\\IEDriverServer.exe";
			System.setProperty("webdriver.ie.driver", service);
			driver = new InternetExplorerDriver();
	  
	    }
	    else if(BROWSER.equalsIgnoreCase("Chrome"))
	    {
	    
				System.setProperty("webdriver.chrome.driver", driverPath+"\\chromedriver.exe");
		      driver = new ChromeDriver();
	   }

/*	System.out.println(driverPath);
	System.setProperty("webdriver.chrome.driver", driverPath+"\\chromedriver.exe");
  driver = new ChromeDriver();*/
	
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 		driver.get(Constant.URL);
	 
	        }
	
	
	@AfterSuite
	public void afterMethod() throws InterruptedException {
	
	  driver.quit();
	  }

@AfterTest

public  void cleanup(){
	s_assert.assertAll();
}
		  
	 
	
	


}

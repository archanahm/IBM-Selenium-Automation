package test.java;

import org.testng.annotations.Test;

import assginmentIBM.Pages.BasePage;
import assignment.Actions.productDetailsHomePage_Action;

public class AddToCartMakePaymentTest extends BaseSpec{
	
	productDetailsHomePage_Action productDetailsHomePage_Obj= new productDetailsHomePage_Action();
	
	@Test
	public void addToCart(){
		productDetailsHomePage_Obj.searchFromCataogery(driver,s_assert);
		productDetailsHomePage_Obj.verifySearchResultReutrned(driver,s_assert);
		productDetailsHomePage_Obj.storeProductdetails(driver);
		productDetailsHomePage_Obj.shoppingOverlayVerificatio(driver, s_assert);
		
	}
	
	

}

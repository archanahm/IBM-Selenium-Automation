package test.java;

import org.testng.annotations.Test;


import assignment.Actions.SignIn_Action;

public class VerifyAuthPageSignInTest extends BaseSpec  {

			SignIn_Action signIN_obj= new SignIn_Action();
			
		
			@Test(priority= 0)
			 public void clickOnSignVerifyAuthPage(){
			
				SignIn_Action.VerifyTitleAndLogo(driver,s_assert);
				signIN_obj.VerifyAuthenticationPage(driver,s_assert);
				
				
				
			}
			@Test (priority= 1)
			public void verifyAuthPageAndSignIn(){

				signIN_obj.verifyAlrdyRigsLayout(driver,s_assert);
				signIN_obj.enterEmailAndPwd(driver,s_assert);

				
			}
			
			@Test(priority= 2)
			 public void verifyAccountpageDetails(){
				
				signIN_obj.verifyAccPageDetails(driver,s_assert);
			}
			
	
}

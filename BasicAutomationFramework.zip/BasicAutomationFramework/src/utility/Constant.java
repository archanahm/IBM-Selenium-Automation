package utility;

public class Constant {
	
	public static final String URL = "http://automationpractice.com/index.php";
	
	public static final String Email = "archanahm17@gmail.com";
	
	public static final String Pwd = "manju#373";
	
	public static final String webLogo = "header_logo";

	public static String pageTitle = "My Store";
	
	public static String authenticationPageHeader= "AUTHENTICATION";
	public static String rigsterlayoutHeader="ALREADY REGISTERED?";
	
	public static String accpageTitle = "MY ACCOUNT";
	
	

}

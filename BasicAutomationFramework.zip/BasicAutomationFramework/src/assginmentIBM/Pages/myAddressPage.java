package assginmentIBM.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class myAddressPage {
	
	
	public String myAddressCartPage(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'breadcrumb clearfix')]/span[2]")).getText();
	    
	    
	}
	
	
	public void clkProceedChkOut(WebDriver driver){
		driver.findElement(By.xpath("//form/p[contains(@class,'cart_navigation')]/button")).click();
	}

}

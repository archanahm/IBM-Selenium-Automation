package assginmentIBM.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShoppingCart_Page {
	
	public String shoppingCartPage(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'breadcrumb clearfix')]/span[2]")).getText();
	    
	    
	}
	
	public String prodNameInshoppingCart(WebDriver driver){
		
		return driver.findElement(By.xpath("//div[contains(@class,'product-name')]/a")).getText();
		
	}
	
	public String prodPriceInshoppingCart(WebDriver driver){
		
		return driver.findElement(By.xpath("//tr[contains(@class,'cart_total_price')][3]/td[2]/span")).getText();
		
	}
	
	public void clkProceedChkOut(WebDriver driver){
		driver.findElement(By.xpath("//div/p[contains(@class,'cart_navigation ')]/a")).click();
	}

}

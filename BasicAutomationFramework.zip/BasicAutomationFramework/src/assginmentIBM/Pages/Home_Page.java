package assginmentIBM.Pages;

import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import utility.WaitFor;




public class Home_Page extends BasePage {
	
	
	private static WebElement element = null;
	public static WebElement lnk_SignIn( WebDriver driver){
		element =   driver.findElement(By.linkText("Sign in"));
		return element;
	}
	
	public static WebElement lnk_SignOut( WebDriver driver){
		element = driver.findElement(By.id(""));
		return element;
	}
	
	public static String verifyTitleOfpage(WebDriver driver) {
	  	  return driver.getTitle();
	  	     	 
 }
	
	public static boolean  verifyLogoDisplayed(WebDriver driver, String logo){
		  	 return driver.findElement(By.id(logo)).isDisplayed();
	 	  	
	  }

	public static WebElement clickOnSignIn(WebDriver driver){
		return driver.findElement(By.linkText("Sign in"));
	}

	public static boolean authenticationPage(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'center_column col-xs-12 col-sm-12')]/h1")).isDisplayed();
	    
	}
	
	public static boolean searchTabDisplayed(WebDriver driver){
		return driver.findElement(By.id("search_block_top")).isDisplayed();
		
	}
	
	public static boolean cartTabDisplayed(WebDriver driver){
		return driver.findElement(By.className("shopping_cart")).isDisplayed();
		
	}
	
	
	public static boolean homeIconDisplayed(WebDriver driver){
		return driver.findElement(By.className("icon-home")).isDisplayed();
		
	}
	
	
	public String signOutButton(WebDriver driver){
		return driver.findElement(By.xpath("//div//a[contains(@class,'logout')]")).getText(); 
	}
	
	public String mouserOverSelectDropDown(WebDriver driver){
		
		WebElement element = driver.findElement(By.xpath("//div/ul/li/a[contains(@title,'Women')]"));
		
	    Actions action = new Actions(driver);
	    
        action.moveToElement(element).build().perform();
        
    	WebElement tmpElement= driver.findElement(By.xpath("//div/ul/li/ul/li/a[contains(@title,'Casual Dresses')]"));
    			JavascriptExecutor executor = (JavascriptExecutor)driver;

    			executor.executeScript("arguments[0].click()", tmpElement);
    	String selCat=	driver.findElement(By.xpath("//div[contains(@class,'breadcrumb clearfix')]")).getText();

       return selCat;
	}

	
	public String verifySelectCatPageDisplayed(WebDriver driver){
		
		String CatName=driver.findElement(By.xpath("//div/h1[contains(@class,'product-listing')]/span")).getText();
		
		return CatName.toLowerCase();
	}
	
	public int totalProductSearchResult(WebDriver driver){
		return driver.findElements(By.className("product-image-container")).size();
		
		
	}
	
	public String getProdName(WebDriver driver){
		return driver.findElement(By.xpath("//div[contains(@class,'right-block')]/h5/a")).getText();
		
	}
	public String getProdPrice(WebDriver driver){
		
		
		element = driver.findElement(By.xpath("//div[contains(@class,'product-container')]"));

	
	    Actions action = new Actions(driver);
	    
        action.moveToElement(element).build().perform();
        
        
		return driver.findElement(By.xpath("//div[contains(@class,'product-container')]/div[2]/div/span")).getText();
		
	}
	
	public void clickonAddtoCart(WebDriver driver){
		
		WebElement element = driver.findElement(By.xpath("//div[contains(@class,'product-container')]"));
		waitForSearchResultsToAppear(driver, By.xpath("//div[contains(@class,'product-container')]"));
	    Actions action = new Actions(driver);
	    
        action.moveToElement(element).build().perform();
        
       // driver.findElement(By.xpath("//div[contains(@class,'product-container')]/div[2]/div[2][contains(@class,'button-container')]")).click();
		
    	WebElement tmpElement= driver.findElement(By.xpath("//div[contains(@class,'product-container')]/div[2]/div[2][contains(@class,'button-container')]/a"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;

		executor.executeScript("arguments[0].click()", tmpElement);
		waitForSearchResultsToAppear(driver, By.id("layer_cart"));
		
		
	
	}
	public boolean isshippingcartDispalyed(WebDriver driver){
		waitForSearchResultsToAppear(driver, By.id("layer_cart"));
		
		return driver.findElement(By.id("layer_cart")).isDisplayed();
		
	}
	
	public String nameofProdInoverlay(WebDriver driver){
		return driver.findElement(By.xpath("//div[contains(@class,'layer_cart_product_info')]/span")).getText();
	}
	
	public String priceOfProdInOverlay(WebDriver driver){
		return driver.findElement(By.xpath("//div/span[contains(@id,'layer_cart_product_price')]")).getText();
		
	}
	

	public void clkProcedFrmOverlay(WebDriver driver){
		waitForSearchResultsToAppear(driver, By.xpath("//div[contains(@class,'product-container')]/div[2]/div[2][contains(@class,'button-container')]/a"));
	
    	WebElement tmpElement= driver.findElement(By.xpath("//div[contains(@class,'product-container')]/div[2]/div[2][contains(@class,'button-container')]/a"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;

		executor.executeScript("arguments[0].click()", tmpElement);
		//driver.findElement(By.xpath("//div[contains(@class,'button-container')]/a")).click();
		
	}
	

	
	 
}

package assginmentIBM.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;



public class Account_Page extends BasePage {
	

	
	private static WebElement element = null;
	public static WebElement lnk_SignIn( WebDriver driver){
		element =   driver.findElement(By.linkText("Sign in"));
		return element;
	}
	
	public void accPageload(WebDriver driver){
		waitForSearchResultsToAppear(driver, By.className("navigation_page"));
	}
	

	public boolean  accPageDiaplayed(WebDriver driver){
		 return isElementPresent(driver,By.className("info-account"));
		
	}
	
	public String accPageTitle(WebDriver driver){
		 return driver.findElement(By.xpath("//div//h1[contains(@class,'page-heading')]")).getText();
		
	}
	
	public boolean orderHistoryTab(WebDriver driver){
		return driver.findElement(By.xpath("//div/ul[contains(@class,'myaccount-link-list')]/li/a/i[contains(@class,'icon-list-ol')]")).isDisplayed(); 
	}
	
	
	public boolean creditSlipTab(WebDriver driver){
		return driver.findElement(By.xpath("//div/ul[contains(@class,'myaccount-link-list')]/li/a/i[contains(@class,'icon-ban-circle')]")).isDisplayed(); 
	}
	
	public boolean myAddrTab(WebDriver driver){
		return driver.findElement(By.xpath("//div/ul[contains(@class,'myaccount-link-list')]/li/a/i[contains(@class,'icon-building')]")).isDisplayed(); 
	}
	
	public boolean myperInfoTab(WebDriver driver){
		return driver.findElement(By.xpath("//div/ul[contains(@class,'myaccount-link-list')]/li/a/i[contains(@class,'icon-user')]")).isDisplayed(); 
	}
	public boolean myWishListTab(WebDriver driver){
		return driver.findElement(By.xpath("//div/ul[contains(@class,'myaccount-link-list')]/li[contains(@class,'lnk_wishlist')]")).isDisplayed(); 
	}
	
	
	
	
	
	

	
	 
}

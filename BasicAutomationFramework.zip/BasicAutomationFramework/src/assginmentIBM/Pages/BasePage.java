package assginmentIBM.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import utility.WaitFor;

public class BasePage {
	
	
	
	  public static void waitForSearchResultsToAppear(WebDriver driver, By by ) {
	        //Conditional wait for one of the elements on the search results page to be present
	        new WaitFor(driver).presenceOfTheElement(by);
	   }
	

	
	public boolean isElementPresent(WebDriver driver,By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
	
	public  String landingPageHeader(WebDriver driver,By by){
		
	     return driver.findElement(by).getText();
	    
	}


}

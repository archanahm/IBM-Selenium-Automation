package assginmentIBM.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShippingPage {


	public String shippingPage(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'breadcrumb clearfix')]/span[2]")).getText();
	    
	    
	}
	
	
	public void acceptTandC(WebDriver driver){
		
	      driver.findElement(By.xpath("//div/p[contains(@class,'checkbox')]")).click();
	    
	    
	}
	
	public void clkProceedChkOut(WebDriver driver){
		driver.findElement(By.xpath("//form/p[contains(@class,'cart_navigation')]/button")).click();
	}

}

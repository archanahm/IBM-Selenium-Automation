package assginmentIBM.Pages;

import org.openqa.selenium.*;

public class Authentication_Page extends BasePage
{
	
	private  WebElement element = null;
	

	public  String ent_emailaddress(WebDriver driver,String emilId) {
	
		driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='email')]")).sendKeys(emilId);
		return driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='email')]")).getAttribute("value");
		//System.out.println(driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='email')]")).getText());
		
		
	}


	public  void  ent_password(WebDriver driver,String passwd) {

		driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='passwd')]")).sendKeys(passwd);;
			
	}
	
	public void submitSignOnBtn(WebDriver driver){
		driver.findElement(By.id("SubmitLogin")).click();
		waitForSearchResultsToAppear(driver,By.xpath("//div//p[contains(@class,'info-account')]"));
	}
	
	public  String authenticationPageHeader(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'center_column col-xs-12 col-sm-12')]/h1")).getText();
	    
	}
	
	public  boolean createAccountLayoutDisplayed(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div[contains(@class,'col-xs-12 col-sm-6')]/form")).isDisplayed();
	    
	}
	public  boolean alrdyRigsLayoutDisplayed(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div//form[contains(@id,'login_form')]")).isDisplayed();
	    
	}
	
	public  String alrdyRigsLayoutHeader(WebDriver driver){
		
	     return driver.findElement(By.xpath("//div//form[contains(@id,'login_form')]/h3")).getText();
	    
	}
	
	public boolean emailAddrTab(WebDriver driver){
		return driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='email')]")).isDisplayed();
		
	}
	
	public boolean pwdAddrTab(WebDriver driver){
		return driver.findElement(By.xpath("//div//input[contains(@class,'is_required validate account_input form-control')][(@name='passwd')]")).isDisplayed();
		
	}
	
	public boolean frgtPwdLink(WebDriver driver){
		return driver.findElement(By.xpath("//div//p[contains(@class,'lost_password form-group')]")).isDisplayed();
		
	}
	
	
	
	
	

	/*public static WebElement VerfiyLogoAuthPage(WebDriver driver) {
		// TODO Auto-generated method stub
		driver.findElement(By.id(""));
		
		
	}*/
	
	
	
	

}

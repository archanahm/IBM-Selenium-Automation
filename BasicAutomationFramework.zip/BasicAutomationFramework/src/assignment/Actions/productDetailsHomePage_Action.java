package assignment.Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import assginmentIBM.Pages.Authentication_Page;
import assginmentIBM.Pages.Home_Page;
import assginmentIBM.Pages.ShippingPage;
import assginmentIBM.Pages.ShoppingCart_Page;
import assginmentIBM.Pages.myAddressPage;
import utility.Constant;

public class productDetailsHomePage_Action extends Home_Page {
	
	Map<String, String> prodDetails = new HashMap<String, String>();
	
	ShoppingCart_Page ShoppingCart_obj= new ShoppingCart_Page();
	Authentication_Page Authentication_obj = new Authentication_Page();
	SignIn_Action signIn_ActionObj = new SignIn_Action();
myAddressPage myAddressPage_obj = new myAddressPage();

ShippingPage shippingPageObj = new ShippingPage();
	
	public void searchFromCataogery(WebDriver driver,SoftAssert s_assert){
		
		String SelectedCAT=mouserOverSelectDropDown(driver);
		
		//s_assert.assertTrue(SelectedCAT.contains(verifySelectCatPageDisplayed(driver)),"\n Selected Category page not displayed");

	}
	
	public void verifySearchResultReutrned(WebDriver driver,SoftAssert s_assert){
		
		if(totalProductSearchResult(driver) > 0)
		{
			System.out.println("Search Result returned");
		}
		else {
			System.out.println("Search Result NOT returned");
			s_assert.fail();
		}

	}
	
	

	public void storeProductdetails(WebDriver driver){
		
		prodDetails.put("ProdName",getProdName(driver));
		prodDetails.put("ProdPrice",getProdPrice(driver));
		System.out.println(prodDetails);
		
			
	}
	
	public void shoppingOverlayVerificatio(WebDriver driver,SoftAssert s_assert ){
		Set<String> handle= driver.getWindowHandles();
		 System.out.println("ARCHANANAN" + handle);
		clickonAddtoCart(driver);


		Set<String> handles= driver.getWindowHandles();
		 System.out.println("ARCHANANAN" + handles);
		if (isshippingcartDispalyed(driver)){

			s_assert.assertTrue(prodDetails.get("ProdName").equals(nameofProdInoverlay(driver)));
			s_assert.assertTrue(prodDetails.get("ProdPrice").equals(priceOfProdInOverlay(driver)));
					
		}else{
			System.out.println("ShoppingCart Overlay Not Dispalyed ");
			
			
		}

	}
	

	
	public void summryPageVerification(WebDriver driver,SoftAssert s_assert ){
		clkProcedFrmOverlay(driver);
		if (ShoppingCart_obj.shoppingCartPage(driver).equals("Your shopping cart")){
			 System.out.println("Shopping cart Page dispalyed");
			 s_assert.assertTrue(prodDetails.get("ProdName").equals(ShoppingCart_obj.prodNameInshoppingCart(driver)));
			 s_assert.assertTrue(prodDetails.get("ProdName").equals(ShoppingCart_obj.prodPriceInshoppingCart(driver)));
			
		}
		else{
			System.out.println("Shopping Cart summry PAGE  Not Dispalyed ");
			s_assert.fail();
			
		}
		
	}
	
	public void authPageVerification(WebDriver driver,SoftAssert s_assert ){
		ShoppingCart_obj.clkProceedChkOut(driver);
		if (Authentication_obj.authenticationPageHeader(driver).equals(Constant.authenticationPageHeader)){
			 System.out.println("Authentication  Page dispalyed");
			 signIn_ActionObj.enterEmailAndPwd(driver, s_assert);
				
		}
		else{
			System.out.println("Authentication PAGE  Not Dispalyed ");
			s_assert.fail();
			
		}
		
	}
	
	
	public void myAddressPageVerification(WebDriver driver,SoftAssert s_assert ){

		if (myAddressPage_obj.myAddressCartPage(driver).equals("Addresses")){
			 System.out.println("MY Address page disaplyed  Page dispalyed");
			 
			 myAddressPage_obj.clkProceedChkOut(driver);
		}
		else{
			System.out.println("Authentication PAGE  Not Dispalyed ");
			s_assert.fail();
			
		}
		
	}
	
	public void shippingPageVerification(WebDriver driver,SoftAssert s_assert ){
	
		if (shippingPageObj.shippingPage(driver).equals("Shipping")){
			 System.out.println("Shipping page disaplyed  Page dispalyed");
			 shippingPageObj.acceptTandC(driver);
			 
			 shippingPageObj .clkProceedChkOut(driver);
		}
		else{
			System.out.println("Shipping PAGE  Not Dispalyed ");
			s_assert.fail();
			
		}
		
	}

	
	



	
}

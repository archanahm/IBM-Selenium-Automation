package assignment.Actions;


import static org.testng.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.testng.asserts.SoftAssert;

import assginmentIBM.Pages.*;
import utility.Constant;
import utility.WaitFor;



public class SignIn_Action extends Home_Page{

	Authentication_Page auth_Page = new Authentication_Page();
	Account_Page acc_page = new Account_Page();

	

	public static void VerifyTitleAndLogo(WebDriver driver, SoftAssert s_assert){
		s_assert.assertTrue(verifyTitleOfpage(driver).equals(Constant.pageTitle),"\n Pagetitle dispalyed is not expected");
		s_assert.assertTrue(verifyLogoDisplayed(driver, Constant.webLogo), "\n Expected logo name not displayed");
	
	
	}
	
	
	public  void VerifyAuthenticationPage(WebDriver driver, SoftAssert s_assert){
		
		clickOnSignIn(driver).click();
		waitForSearchResultsToAppear(driver,By.className("navigation_page"));
		
		if(authenticationPage(driver)){
			// verify all the required fields in authentication page
			s_assert.assertTrue(auth_Page.authenticationPageHeader(driver).equals(Constant.authenticationPageHeader),"\n Authenticaton page not displayed");
			s_assert.assertTrue(searchTabDisplayed(driver), "\n SearchTab Not displayed In auth Page");
			s_assert.assertTrue(cartTabDisplayed(driver),"\n Cart tab not dispalyed");
			s_assert.assertTrue(homeIconDisplayed(driver),"\n Home Icon not dispalyed");
			s_assert.assertTrue(auth_Page.createAccountLayoutDisplayed(driver),"\n Create account layout Not displayed");
			//s_assert.assertTrue(auth_Page.alrdyRigsLayoutDisplayed(driver),"\n Already Rigisterd layout dispalyed");
			
		}
		else{
			System.out.println("AUTHENTICATION PAGE NOT DISPLAYED");
			s_assert.fail();
		}
	}
	
	public void verifyAlrdyRigsLayout(WebDriver driver, SoftAssert s_assert){
		//Log.info("Verification of login Form ");
		if(auth_Page.alrdyRigsLayoutDisplayed(driver)){
			s_assert.assertTrue(auth_Page.alrdyRigsLayoutHeader(driver).equals(Constant.rigsterlayoutHeader),"\n Rigister layout Header Not displayed");
			s_assert.assertTrue(auth_Page.emailAddrTab(driver),"\n Email address tab not displayed");
		s_assert.assertTrue(auth_Page.emailAddrTab(driver),"\n Tab to enter email address not dispalyed");
		s_assert.assertTrue(auth_Page.pwdAddrTab(driver),"\n Tab to enter Password  not dispalyed");
		s_assert.assertTrue(auth_Page.frgtPwdLink(driver),"\n Link to forgot address not dispalyed");
		
		
		}else
		{
			System.out.println("ALREADY RIGISTERED? layout NOT DISPLAYED");
			s_assert.fail();
		}
	}
	
	public void enterEmailAndPwd(WebDriver driver, SoftAssert s_assert){
		s_assert.assertTrue(auth_Page.ent_emailaddress(driver, Constant.Email).equals(Constant.Email),"\n email tab is not working , entered email addressed is not dispalyed in email tab ");
		auth_Page.ent_password(driver, Constant.Pwd);
		auth_Page.submitSignOnBtn(driver);
		acc_page.accPageload(driver);
		
	}
	
	public void verifyAccPageDetails(WebDriver driver, SoftAssert s_assert){

		if (acc_page.accPageDiaplayed(driver)){
			
			s_assert.assertTrue(acc_page.accPageTitle(driver).equals(Constant.accpageTitle),"\n Account page title is not displayed");
			s_assert.assertTrue(acc_page.orderHistoryTab(driver), "\n Order history tab not displayed");
			s_assert.assertTrue(acc_page.creditSlipTab(driver),"\n credit slip tab not displayed");
			s_assert.assertTrue(acc_page.myAddrTab(driver),"\n My address tab not displayed");
			s_assert.assertTrue(acc_page.myperInfoTab(driver),"\n My Personal tab not displayed");
			s_assert.assertTrue(acc_page.myWishListTab(driver),"\n credit slip tab not displayed");
			s_assert.assertTrue(signOutButton(driver).equals("Sign out"),"\n Signout text not dispalyed");
			
		
		}
		else{
			
			fail("Accouont page layout NOT DISPLAYED");
		
		
		}
	}

	public static void isDispalyed(By by){

		
	}

}
